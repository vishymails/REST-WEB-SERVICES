package GeoLocate;
import java.util.*;

public class LatLonwithDistance implements Comparable<LatLonwithDistance>{
	public double Lat;
	public double Lon;
	public double distance;
	
	public double getDistance() {
		return distance;
	}
	public void setDistance(double distance) {
		this.distance = distance;
	}
	public double getLat() {
		return Lat;
	}
	
	public void setLat(double lat) {
		Lat = lat;
	}
	
	public double getLon() {
		return Lon;
	}
	public void setLon(double lon) {
		Lon = lon;
	}
	@Override
	public int compareTo(LatLonwithDistance o) {
		// TODO Auto-generated method stub
		return (int) (this.distance*1000 - o.distance*1000);
	}
	
}
