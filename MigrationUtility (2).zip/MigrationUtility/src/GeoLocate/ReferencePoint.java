package GeoLocate;

import org.codehaus.jackson.annotate.JsonProperty;

public class ReferencePoint {
	@JsonProperty
	public double Latitude;
	@JsonProperty
	public double Longitude;
	public double getLatitude() {
		return Latitude;
	}
	public void setLatitude(double latitude) {
		Latitude = latitude;
	}
	public double getLongitude() {
		return Longitude;
	}
	public void setLongitude(double longitude) {
		Longitude = longitude;
	}
	
	
	
	
}
