package GeoLocate;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;

import javax.ws.rs.Consumes;

import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

@Path("/geoExecution")
public class ExecuteResult {
	
	@POST
	@Produces(value = { MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes(value = { MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	
	@Path("/calculateDistance")
	public Response distancecalculation(LatLon ll) throws IOException{
		
		double dist = Distance.getDistanceFromLatLonInKm(ll.Lat1, ll.Lon1, ll.Lat2, ll.Lon2);
		double val= Math.round(dist*100.0)/100.0;
		System.out.println("kiloMeter (Math.round) : " + val);
		
		PositionVO pv = new PositionVO();
		pv.setDistanceKM(val);
		
		Response response = null;
		response = Response.status(200).entity(pv).build();
		return response;
	}
	

	@POST
	@Produces(value = { MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes(value = { MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	
	@Path("/nearByLatLong")
	public Response nearBy(GeoPoints gp) throws IOException{
		
		ReferencePoint refp= gp.getReferencePoint();
		
		double radiusDist = gp.getDistanceKM();
		//System.out.println(radiusDist);
		CalDistResult cdr = new CalDistResult();
		cdr.setResult(new ArrayList<PositionVOGeoPoint>());
		ArrayList<LatLon2> ll = gp.getArray();
		//System.out.println(new Gson().toJson(ll));
		
		  for(LatLon2 l:ll){

			 // System.out.println("distance :::: "+Distance.getDistanceFromRef(gp.getReferencePoint(),l.Lat2, l.Lon2));
			  if(Distance.getDistanceFromRef(gp.getReferencePoint(),l.Lat2, l.Lon2)<=radiusDist){
				 
				//  System.out.println("inner distance :::: "+Distance.getDistanceFromRef(gp.getReferencePoint(),l.Lat2, l.Lon2));
				  PositionVOGeoPoint pvgp = new PositionVOGeoPoint();
				  pvgp.setLatitude(l.getLat2());
				  pvgp.setLongitude(l.getLon2());
				  cdr.getResult().add(pvgp);
				 
				 // System.out.println(getDistanceFromLatLongInKm(l.Lat, l.Lon));
				// System.out.println( p.getLon()+" "+ p.getLat());	 
			  }
			  
		  }
				
		Response response = null;
		response = Response.status(200).entity(cdr).build();
		return response;
	}
	
	@POST
	@Produces(value = { MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes(value = { MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	
	@Path("/shortCordinates")
	public Response shortCordinates(GeoPoints gp) throws IOException{
		
		ReferencePoint refp= gp.getReferencePoint();
		ArrayList<LatLon2> ll = gp.getArray();
		System.out.println(new Gson().toJson(ll));
		
		ShortResult sr = new ShortResult();
		sr.setShortedArray(new ArrayList<PositionVOGeoPoint>());
		
		  ArrayList<LatLonwithDistance> lld = new ArrayList<LatLonwithDistance>();
		  for(LatLon2 l:ll){
			  
				  LatLonwithDistance ld = new LatLonwithDistance();
				  ld.setLat(l.Lat2);
				  ld.setLon(l.Lon2);
				  ld.setDistance(Distance.getDistanceFromRef(refp, l.Lat2, l.Lon2));
				  lld.add(ld);
				//  System.out.println(getDistanceFromLatLongInKm(l.Lat, l.Lon));
				// System.out.println( ld.getLon()+" "+ ld.getLat()+" "+ld.getDistance());
				 
		  }
		 Collections.sort(lld);
		
		    for(LatLonwithDistance lld1: lld){
		
		      PositionVOGeoPoint ld1 = new PositionVOGeoPoint();
			  ld1.setLatitude(lld1.Lat);
			  ld1.setLongitude(lld1.Lon);
			  sr.getShortedArray().add(ld1);
			  
			//  System.out.println(  sr.getShortedArray().add(ld1));
			//  System.out.println( lld1.getLon()+" "+ lld1.getLat()+" "+lld1.getDistance());
			  
			 }
		  
		  Response response = null;
			response = Response.status(200).entity(sr).build();
			return response;
	  }
	/*public static void main(String[] args) throws IOException {
		ExecuteResult er = new ExecuteResult();
		//System.out.println(er.distancecalculation(new LatLon(28.458581, 77.071464, 28.463296, 77.094853)));
	}*/
}
