package GeoLocate;

import java.util.ArrayList;

public class ShortResult {

	/* ArrayList<LatLonwithDistance> shortedArray;

	public ArrayList<LatLonwithDistance> getShortedArray() {
		return shortedArray;
	}

	public void setShortedArray(ArrayList<LatLonwithDistance> shortedArray) {
		this.shortedArray = shortedArray;
	}*/
	 
	private ArrayList<PositionVOGeoPoint> shortedArray;

	public ArrayList<PositionVOGeoPoint> getShortedArray() {
		return shortedArray;
	}

	public void setShortedArray(ArrayList<PositionVOGeoPoint> shortedArray) {
		this.shortedArray = shortedArray;
	}
	
	
}
