package GeoLocate;

import org.codehaus.jackson.annotate.JsonProperty;

public class LatLon2 {

	@JsonProperty
	double Lat2;
	@JsonProperty
	double Lon2;
	public double getLat2() {
		return Lat2;
	}
	public void setLat2(double lat2) {
		Lat2 = lat2;
	}
	public double getLon2() {
		return Lon2;
	}
	public void setLon2(double lon2) {
		Lon2 = lon2;
	}
}
