package GeoLocate;

public class PositionVO {

	public double distanceKM;

	public double getDistanceKM() {
		return distanceKM;
	}

	public void setDistanceKM(double distanceKM) {
		this.distanceKM = distanceKM;
	}
	
	
	
	
	/*public double result;
	public String s;

	public double getResult() {
		return result;
	}

	public void setResult(double val) {
		this.result = val;
	}

	public String getS() {
		return s;
	}

	public void setS(String s) {
		this.s = s;
	}*/

	
}
