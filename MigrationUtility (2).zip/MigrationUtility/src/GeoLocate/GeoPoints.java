package GeoLocate;

import java.util.ArrayList;

public class GeoPoints {
	
	ArrayList<LatLon2> array = new ArrayList<LatLon2>();
	ReferencePoint referencePoint ;
	public double distanceKM;
	
	
	public ReferencePoint getReferencePoint() {
		return referencePoint;
	}

	public void setReferencePoint(ReferencePoint referencePoint) {
		this.referencePoint = referencePoint;
	}

	public ArrayList<LatLon2> getArray() {
		return array;
	}

	public void setArray(ArrayList<LatLon2> array) {
		this.array = array;
	}

	public double getDistanceKM() {
		return distanceKM;
	}

	public void setDistanceKM(double distanceKM) {
		this.distanceKM = distanceKM;
	}

	
	
	
}
