package com.newgen.rest.service;

public class TemplateImportVO {
	String FolderPath;


	public String getFolderPath() {
		return FolderPath;
	}

	public void setFolderPath(String folderPath) {
		FolderPath = folderPath;
	}
	
}
