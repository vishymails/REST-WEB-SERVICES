package com.newgen.rest.service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Properties;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.log4j.Logger;


@Path("/migration")
public class TestRestServiceClass {
//	Logs l=new Logs();
	
	static Logger log = Logger.getLogger(TestRestServiceClass.class.getName());
	
	
	@POST
	@Produces(value = { MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes(value = { MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	
	@Path("/exportVerify")
	public Response processTemplate(TemplateInputVO vo) throws IOException {
	
		//Logger logger=Logs.main();
		String[] stringArray = vo.getProductNameArray();
		MigrationOutputVO mvo = new MigrationOutputVO();
		try {
			
			log.info("We are inside ExportVerify.");
		
		//	Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			

			Connection con = null;
			ArrayList<String> successList = new ArrayList<String>();
			ArrayList<String> failedList = new ArrayList<String>();
	

			Properties prop = new Properties();
			InputStream input = null;
			String Key = null;
		
			try {

				String filename = "abc.properties";
				input = property.class.getClassLoader().getResourceAsStream(filename);
				if (input == null) {
					//log.info("Sorry, unable to find " + filename);
					log.info("Sorry, unable to find " + filename);

				}

				prop.load(input);

			} catch (IOException ex) {
				ex.printStackTrace();
				log.info(ex.toString());
			} finally {
				if (input != null) {
					try {
						input.close();
					} catch (IOException e) {
						//e.printStackTrace();
						log.info(e.toString());
					}
				}
			}


			String DBUser = prop.getProperty("DBUser");
			log.info("DB User is"+DBUser);
			String CabinetName = prop.getProperty("ExportCabinetName");
			String DBIP = prop.getProperty("DBIP");
			String DBPassword = prop.getProperty("DBPassword");
			String Path= prop.getProperty("Path");
			String ServiceName=prop.getProperty("ServiceName");
			String DBport=prop.getProperty("DBport");
			String OMSPath=prop.getProperty("OMNIOMSPath");
			String FolderName = "" + System.currentTimeMillis();
	
			log.info("FolderName is "+ FolderName);

			int length = stringArray.length;
		    log.info("The length of the array is " + stringArray.length);
		
			
			try {
		
				con=ConnectionManager.getConnection(DBUser, DBPassword, DBIP, DBport, ServiceName);
			} catch (Exception e) {
						
							log.info("Unable To Connect");

			}
			for (int j = 0; j < length; j++) {
				log.info(stringArray[j].trim());
				stringArray[j] = stringArray[j].trim();
				
				log.info("ProductName are "+ stringArray[j]);
			}

			for (int k = 0; k < length; k++) {

				//log.info("Entering the loop for k = " + k);
				log.info("Entering the loop for k = " + k);
				Statement stmt = con.createStatement();
				int Category1 = 0;
				int Comm1 = 0;
				int version1 = 0 ;
				String version=null;
				String Comm=null;
				String Category=null;
				String version2 = null;
				String Checkout = null;
				String query = "select * from ReportMast where ProductName='" + stringArray[k] + "'";
				log.info("Insert Query is "+"select * from ReportMast where ProductName='" + stringArray[k] + "'" );
				ResultSet rs = stmt.executeQuery("select * from ReportMast where ProductName='" + stringArray[k] + "'");

				if (rs.isBeforeFirst() == false) {
					//log.info("ProductName Invalid");
					
				  Failure fl=new Failure();
					fl.setProductname(stringArray[k]);
					fl.setDescription("ProductName Invalid");
					log.info("ProductName Invalid");
					mvo.FailureList.add(fl);
					;
					continue;
				}
				while (rs.next()) {

					Category1 = rs.getInt(2);
					Comm1 = rs.getInt(3);
					version1 = rs.getInt(1);
					version2 = rs.getString(13);
					Checkout = rs.getString(7);
					 version=String.format("%08d", version1);
					 Comm=String.format("%04d", Comm1);
					Category=String.format("%04d", Category1);
				}
				char c = Checkout.charAt(0);

				if (c == 'N') {
					log.info("Please check out report with productname" + stringArray[k]);
					failedList.add(stringArray[k]);

					
					Failure fl=new Failure();
					fl.setDescription("Please check out report with productname " + stringArray[k]);
					fl.setProductname(stringArray[k]);
					mvo.FailureList.add(fl);

					continue;

				}
				
		// Vishal
				/*OutputStream DBScript = null;
				//Writing Error to Error File
					System.err.println("This goes to the console");
					PrintStream console = System.err;
					PrintStream ps = new PrintStream(new FileOutputStream(new File("C:/Users/vishal.verma/Desktop/Samba Newgen Migration Tool/Export/error.txt")));
					System.setErr(ps);
					System.err.println("This goes to err.txt");
					
			        try {
			        	DBScript = new FileOutputStream(new File("C:/Users/vishal.verma/Desktop/Samba Newgen Migration Tool/Export/script.sql"));
			            //os.write(getScript().getBytes(), 0, getScript().length());
			        	DBScript.write(CheckExportScript.getScript().getBytes(), 0, CheckExportScript.getScript().length());
			        } catch (IOException e) {
			            e.printStackTrace();
			        }finally{
			            try {
			            	DBScript.close();
			            } catch (IOException e) {
			                e.printStackTrace();
			            }
			        }
			        System.setErr(console);
					System.err.println("This also goes to the console");
*/

		// Expot DB Table/View Script Code - Vishal 

				String xml_path = OMSPath+"NEWGEN OmniOMS/OmniOMS Designer/Layout/"+CabinetName+"/" + Category + "/" + Comm
						+ "/Designs/1/" + version + "_v" + version2 + ".xml";
				log.info("Path for XML is "+xml_path);
				java.nio.file.Path source_xml = Paths.get(xml_path);
				if (Files.notExists(source_xml)) {
					log.info("Checked out on other Device");
					failedList.add(stringArray[k]);

				
					Failure fl=new Failure();
					fl.setDescription("Checked out on other Device");
					mvo.FailureList.add(fl);
					fl.setProductname(stringArray[k]);

					

					continue;
				}
				Success sc=new Success();
				sc.setProductname(stringArray[k]);
				
				mvo.SuccessList.add(sc);
				successList.add(stringArray[k]);
			}
			log.info("Success " + successList);
			log.info("Failure " + failedList);

			//log.info("FL: " + mvo.FailureList);
			//log.info("SC :" + mvo.SuccessList);
		//	log.info(mvo);
		} catch (Exception e) {
			e.printStackTrace();
			log.info(e.toString());
		}

		Response response = null;
		response = Response.status(200).entity(mvo).build();
		//log.info(response.getMetadata());
		return response;
	}
	@POST
	@Produces(value = { MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes(value = { MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/export")
	
	public Response ExportTemplate(TemplateInputVO vo) throws IOException{
		//Logger logger=Logs.main();
		//Logger logger=Logs.main();
		ExportOutputVO evo=new ExportOutputVO();
		String[] stringArray = vo.getProductNameArray();
		String xml_path;
		java.nio.file.Path source_xml = null;
		java.nio.file.Path destination_xml=null;
		Connection con=null;
		ArrayList<String> successList = new ArrayList<String>();
		ArrayList<String> failedList = new ArrayList<String>();
		int Category1 = 0;
		int Comm1 = 0;
		int version1 = 0 ;
		String version=null;
		String Comm=null;
		String Category=null;
		String version2 = null;
		String Checkout = null;
		int k=0;
	 	Properties prop = new Properties();
    	InputStream input = null;
    	String Key = null;	
    	
   	
    	try {
        log.info("We are Inside Export Function.");
    		String filename = "abc.properties";
    		input = property.class.getClassLoader().getResourceAsStream(filename);
    		if(input==null){
    	            log.info("Sorry, unable to find " + filename);
    		   
    		}

   
    		prop.load(input);


	    	String DBUser=prop.getProperty("DBUser");
	    	log.info("Db user is "+DBUser);
	    	String CabinetName=prop.getProperty("ExportCabinetName");
	    	String DBIP=prop.getProperty("DBIP");
	    	String DBPassword=prop.getProperty("DBPassword");
	    	String Path=prop.getProperty("Path");
	    	String ServiceName=prop.getProperty("ServiceName");
	    	String DBport=prop.getProperty("DBport");
	    	String OMSPath=prop.getProperty("OMNIOMSPath");
	    	String FolderName=""+System.currentTimeMillis();
	    	//String[] stringArray={"UNDERWRITERV2","HCCI_DO_BE_SC_V1_WORD"};
	    
	    //	Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			try
			{
				/*String dbConnectionString = "jdbc:sqlserver://"+DBIP+";user="+DBUser+";password="+DBPassword+";database="+CabinetName+"";
				log.info("Connect string is "+dbConnectionString);
				 con = DriverManager.getConnection(dbConnectionString);*/
				con=ConnectionManager.getConnection(DBUser, DBPassword, DBIP, DBport, ServiceName);
			}
			catch(Exception e)
			{
	
				log.info("Unable To Connect");
				
				
			}
			Statement stmt = con.createStatement();
			
		for(int k1=0;k1<stringArray.length;k1++)
		{
			
			String query="select * from ReportMast where ProductName='" + stringArray[k1] + "'";
			ResultSet rs = stmt.executeQuery("select * from ReportMast where ProductName='" + stringArray[k1] + "'");
		
			
			while (rs.next()) {

				Category1 = rs.getInt(2);
				Comm1 = rs.getInt(3);
				version1 = rs.getInt(1);
				version2 = rs.getString(13);
				Checkout = rs.getString(7);
				 version=String.format("%08d", version1);
				 Comm=String.format("%04d", Comm1);
				Category=String.format("%04d", Category1);
			}
	
		File files = new File(Path+"/Export/"+FolderName+"/" + stringArray[k1] + "");

// Expot DB Table/View Script Code - Vishal 
		
		/*File Relationfile1=new File( OMSPath+"NEWGEN OmniOMS/OmniOMS Designer/Relation/"+CabinetName+"/" + Category + "/"
				+ Comm + "/Relation.xml");
		ArrayList<String> TablesName=ExportScriptTableName.RelationPrase(Relationfile1);
		if(TablesName.isEmpty())
		{
			log.info("Table/View does not exist in "+DBUser+"Cabinet");
		}
		else
		{
			
			ArrayList<String> tables = new ArrayList<>();
			ArrayList<String> views = new ArrayList<>();
			//tables = new String[TablesName.size()];
			 for(String obj: TablesName){
				 if(obj.contains("V_")){
					 views.add(obj);
					 System.out.println(tables);
					 log.info("Views in current report are: "+views);
				 }
				 else{
					 tables.add(obj);
					 System.out.println(tables);
					 log.info("Tables in current report are: "+tables);
				 }
			 }
			 String scriptData=null;
			 for(String t: tables){
				 String qry="select dbms_metadata.get_ddl( 'TABLE', '"+t+"', 'SAMBA' ) from dual"  ;
					ResultSet rs1 = stmt.executeQuery(qry);
				
					
					while (rs1.next()) {
						scriptData= rs1.getString(1);
						System.out.println(scriptData);
						log.info("Complete Script Data is : "+scriptData);
					}
			 }
			 for(String v: views){
				 String qry="select dbms_metadata.get_ddl( 'TABLE', '"+v+"', 'SAMBA' ) from dual"  ;
					ResultSet rs1 = stmt.executeQuery(qry);
				
					
					while (rs1.next()) {
						scriptData= rs1.getString(1);
						System.out.println(scriptData);
						log.info("Complete Script Data is : "+scriptData);
					}
			 }
			Statement stmt1= con.createStatement();
			for(String tName: TablesName){
				String qry="select dbms_metadata.get_ddl( 'VIEW', 'USERGROUPMAST', 'SAMBA' ) from dual;";
			}
		}*/
		
		OutputStream DBScript = null;
		//Writing Error to Error File
			System.err.println("This goes to the console");
			PrintStream console = System.err;
			PrintStream ps = new PrintStream(new FileOutputStream(new File(Path+"/Export/Error.txt")));
			System.setErr(ps);
			System.err.println("This goes to err.txt");
			
	        try {
	        	DBScript = new FileOutputStream(new File(Path+"/Export/Script.sql"));
	            //os.write(getScript().getBytes(), 0, getScript().length());
	        	DBScript.write(CheckExportScript.getScript().getBytes(), 0, CheckExportScript.getScript().length());
	        } catch (IOException e) {
	            e.printStackTrace();
	        }finally{
	            try {
	            	DBScript.close();
	            } catch (IOException e) {
	                e.printStackTrace();
	            }
	        }
	        System.setErr(console);
			System.err.println("This also goes to the console");


// Expot DB Table/View Script Code - Vishal 
		
		if (!files.exists()) {
			if (files.mkdirs()) {
			log.info("Multiple directories are created!");
			} else {
			log.info("Failed to create multiple directories!");
			}
		}
		 xml_path = OMSPath+"NEWGEN OmniOMS/OmniOMS Designer/Layout/"+CabinetName+"/" + Category + "/" + Comm
					+ "/Designs/1/" + version + "_v" + version2 + ".xml";
			log.info("XML path is "+xml_path);
			 source_xml =java.nio.file.Paths.get(xml_path);
			 destination_xml =java.nio.file.Paths.get(Path+"/Export/"+FolderName+"/" + stringArray[k1] + "/xml.xml");
			 log.info("Destination path is "+destination_xml );
		Files.copy(source_xml, destination_xml, StandardCopyOption.REPLACE_EXISTING);
		
				String tiff_path = OMSPath+"NEWGEN OmniOMS/OmniOMS Designer/Images/"+CabinetName+"/" + Category + "/" + Comm
						+ "/Designs/1/" + version + "_v" + version2 + ".tiff";
				log.info("Tiff Source Path is"+tiff_path);
				java.nio.file.Path source_Tiff = java.nio.file.Paths.get(tiff_path);
				try {
					java.nio.file.Path Destination_tiff = java.nio.file.Paths
							.get(Path+"/Export/"+FolderName+"/" + stringArray[k1] + "/tiff.tiff");
					log.info("Destination TIFF is"+Destination_tiff);
					Files.copy(source_Tiff, Destination_tiff, StandardCopyOption.REPLACE_EXISTING);
				} catch (Exception ex) {
					log.info("No Tiff Exists");

				}
				String Relation_path = OMSPath+"NEWGEN OmniOMS/OmniOMS Designer/Relation/"+CabinetName+"/" + Category + "/"
						+ Comm + "/Relation.xml";
				log.info("Reslation Path is "+Relation_path);
				java.nio.file.Path source_Relation = Paths.get(Relation_path);
				java.nio.file.Path Destination_Relation = Paths
						.get(Path+"/Export/"+FolderName+"/" + stringArray[k1] + "/Relation.xml");
				log.info("Destination Relation "+Destination_Relation);
				Files.copy(source_Relation, Destination_Relation, StandardCopyOption.REPLACE_EXISTING);
			
				
				successList.add(stringArray[k1]);
				
			//	String SOURCE_FOLDER=Path+"/Export/"+FolderName;
			//	String OUTPUT_ZIP_FILE=Path+"/Export/"+FolderName+".zip";
			//	ZipUtils appZip = new ZipUtils();
			    //    appZip.generateFileList(new File(SOURCE_FOLDER));
			     //   appZip.zipIt(OUTPUT_ZIP_FILE);
			       // deleteDirectory("one"); // wrong way to remove a directory in Java
			       // ZipUtils.deleteDirectory(new File(SOURCE_FOLDER));

		}
		evo.setOutput("Success Export File Stored at path"+Path+"/Export/");
		 ZipUtils.zipFolder(Path+"/Export/"+FolderName, Path+"/Export/"+FolderName+".zip");
		   System.gc();
		   // File f2=new File(Path+"/Export/"+FolderName);
		  Delete d1=new Delete();
		    d1.delete(Path+"/Export/"+FolderName);	

		    File fl=new File( Path+"/Export/"+FolderName+".zip");
		    fl.renameTo(new File( Path+"/Export/"+FolderName+".mdb"));
				
		}
		 catch (Exception e) {
				e.printStackTrace();
				log.info(e.toString());
			}
		
		Response response = null;
		response = Response.status(200).entity(evo).build();
		return response;
		
	}
	
	@POST
	@Produces(value = { MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes(value = { MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	
	@Path("/importVerify")
	public Response ImportVerify(TemplateImportVO vo) throws IOException{
		MigrationOutputVO mvo = new MigrationOutputVO();
		//Logger logger=Logs.main();
		//Logger logger=Logs.main();
		log.info("We are inside importVerify Function");
		String ImportPath=vo.getFolderPath();
		ImportPath=ImportPath.replaceAll("\\\\","/");
		File fle=new File(ImportPath);
		String Path1=ImportPath.replace("mdb", "zip");
  	    fle.renameTo(new File(Path1));
  	    System.out.println("Path is "+Path1);
  	    String zipFilePath =Path1;

  	    String destDir =Path1.replace(".zip", "");
  	    System.out.println("Dest dir "+destDir);
  	    Delete dl=new Delete();
  	    UnZip.unzip(zipFilePath, destDir);
      
  	    ImportPath=Path1.replace(".zip", "");
  	    int first=ImportPath.lastIndexOf("/");
  	    String FolderPath=ImportPath.substring(first+1);
  	    String  ImportPath1=ImportPath+"/"+FolderPath;
  	    System.out.println("import is"+ImportPath1);
		File file = new File( ImportPath1);
	    String[] stringArray = file.list();
	    for(String name:stringArray){
	            log.info(name);
	        }
	        try {

				//Success sc = new Success();
				//Failure fl = new Failure();
				
			//	Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			

				Connection con = null;
				ArrayList<String> successList = new ArrayList<String>();
				ArrayList<String> failedList = new ArrayList<String>();
				ArrayList<String> error = new ArrayList<String>();

				Properties prop = new Properties();
				InputStream input = null;
				String Key = null;
				// String ProductName=null;
				try {

					String filename = "abc.properties";
					input = property.class.getClassLoader().getResourceAsStream(filename);
					if (input == null) {
						log.info("Sorry, unable to find " + filename);

					}

					prop.load(input);

				} catch (IOException ex) {
					ex.printStackTrace();
				} finally {
					if (input != null) {
						try {
							input.close();
						} catch (IOException e) {
						log.info(e.toString());	
						}
					}
				}

				//String ProductName = prop.getProperty("Productname");
				String DBUser = prop.getProperty("DBUser");
				log.info("DB user: "+DBUser);
				String CabinetName = prop.getProperty("ImportcabinetName");
				String DBIP = prop.getProperty("DBIP");
				String DBPassword = prop.getProperty("DBPassword");
				String Path= prop.getProperty("Path");
				String OMSPath=prop.getProperty("OMNIOMSPath");
				String FolderName = "" + System.currentTimeMillis();
				log.info("FolderName: "+FolderName);
				String ServiceName=prop.getProperty("ServiceName");
				String DBport=prop.getProperty("DBport");
				int length = stringArray.length;
				log.info("The length of the array is " + stringArray.length);
				//	log.info("jdbc:sqlserver://" + DBIP + ":1433;user=" + DBUser + ";password=" + DBPassword
				//		+ ";database=" + CabinetName + "");
				try {
					/*String dbConnectionString = "jdbc:sqlserver://" + DBIP + ";user=" + DBUser + ";password=" + DBPassword
							+ ";database=" + CabinetName + "";
					con = DriverManager.getConnection(dbConnectionString);*/
					con=ConnectionManager.getConnection(DBUser, DBPassword, DBIP, DBport, ServiceName);
				} catch (Exception e) {
					
					log.info("Unable To Connect");

				}
				for (int j = 0; j < length; j++) {
					log.info(stringArray[j].trim());
					stringArray[j] = stringArray[j].trim();
					log.info("ProductName Are: "+stringArray[j]);
				}

				for (int k = 0; k < length; k++) {

					log.info("Entering the loop for k = " + k);
					Statement stmt = con.createStatement();
					int Category1 = 0;
					int Comm1 = 0;
					int version1 = 0 ;
					String version=null;
					String Comm=null;
					String Category=null;
					String version2 = null;
					String Checkout = null;
					String query = "select * from ReportMast where ProductName='" + stringArray[k] + "'";
					log.info("The Query to Execute is "+query);
					ResultSet rs = stmt.executeQuery("select * from ReportMast where ProductName='" + stringArray[k] + "'");

					if (rs.isBeforeFirst() == false) {
						log.info("ProductName Invalid");
						
					  Failure fl=new Failure();
						fl.setProductname(stringArray[k]);
						fl.setDescription("ProductName Invalid");
						mvo.FailureList.add(fl);
						;
						continue;
					}
					while (rs.next()) {

						Category1 = rs.getInt(2);
						Comm1 = rs.getInt(3);
						version1 = rs.getInt(1);
						version2 = rs.getString(13);
						Checkout = rs.getString(7);
						 version=String.format("%08d", version1);
						 Comm=String.format("%04d", Comm1);
						Category=String.format("%04d", Category1);
					}
					char c = Checkout.charAt(0);

					if (c == 'N') {
						log.info("Please check out report with productname" + stringArray[k]);
						failedList.add(stringArray[k]);

						
						Failure fl=new Failure();
						fl.setDescription("Please check out report with productname " + stringArray[k]);
						fl.setProductname(stringArray[k]);
						mvo.FailureList.add(fl);

						continue;

					}

					String xml_path = OMSPath+"NEWGEN OmniOMS/OmniOMS Designer/Layout/"+CabinetName+"/" + Category + "/" + Comm
							+ "/Designs/1/" + version + "_v" + version2 + ".xml";
					log.info("Xml Path is"+xml_path);
					java.nio.file.Path source_xml = Paths.get(xml_path);
					if (Files.notExists(source_xml)) {
						log.info("Checked out on other Device");
						failedList.add(stringArray[k]);

					
						Failure fl=new Failure();
						fl.setDescription("Checked out on other Device");
						mvo.FailureList.add(fl);
						fl.setProductname(stringArray[k]);

					

						continue;
					}
					File Relationfile=new File( OMSPath+"NEWGEN OmniOMS/OmniOMS Designer/Relation/"+CabinetName+"/" + Category + "/"
							+ Comm + "/Relation.xml");
					ArrayList<String> faultlist=RelationParser.RelationPrase(Relationfile);
					if(faultlist.isEmpty())
					{
						Success sc=new Success();
						sc.setProductname(stringArray[k]);
						
						mvo.SuccessList.add(sc);
						successList.add(stringArray[k]);
					}
					else
					{

						Failure fl=new Failure();
						fl.setDescription("Following Table/View does not exist in "+DBUser+"Cabinet"+ faultlist);
						mvo.FailureList.add(fl);
						fl.setProductname(stringArray[k]);
					}

				}
				log.info("Success " + successList);
				log.info("Failure: "+ failedList);
				System.gc();
				dl.delete(ImportPath);
				File f3=new File(ImportPath+".zip");
				f3.renameTo(new File(ImportPath+".mdb"));
				//log.info("FL: " + mvo.FailureList);
				//log.info("SC :" + mvo.SuccessList);
			} catch (Exception e) {
				e.printStackTrace();
				log.info(e.toString());
			}
		Response response = null;
		response = Response.status(200).entity(mvo).build();
		return response;
		
	}
	@POST
	@Produces(value = { MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes(value = { MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	
	@Path("/import")
	public Response Import(TemplateInputImportVO vo) throws IOException{
		//Logger logger=Logs.main();
		//Logger logger=Logs.main();
		log.info("We are inside import Function");
		String stringArray[]=vo.getProductNameArray();
		String folderpath=vo.getFolderPath();
		folderpath=folderpath.replaceAll("\\\\","/");
		int First=folderpath.lastIndexOf(".");
		log.info(First+"");
		String FolderName=folderpath.substring(folderpath.lastIndexOf("/")+1, First);
		log.info(FolderName);
		ExportOutputVO evo=new ExportOutputVO();
		String ImportPath=vo.getFolderPath();
		  File fle=new File(ImportPath);
		  String Path1=ImportPath.replace("mdb", "zip");
	    fle.renameTo(new File(Path1));
	    System.out.println("Path is "+Path1);
	    String zipFilePath =Path1;

    String destDir =Path1.replace(".zip", "");
    System.out.println("Dest dir "+destDir);
    Delete dl=new Delete();
    UnZip.unzip(zipFilePath, destDir);
    
   ImportPath=Path1.replace(".zip", "");
   int first=ImportPath.lastIndexOf("/");
   String FolderPath=ImportPath.substring(first+1);
  String  ImportPath1=ImportPath+"/"+FolderPath;
   System.out.println("import is"+ImportPath1);
		try {
		//	Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			Connection con=null;
		
			Properties prop = new Properties();
	    	InputStream input = null;
	    	String Key = null;
	    	
	    	try {
	        
	    		String filename = "abc.properties";
	    		input = property.class.getClassLoader().getResourceAsStream(filename);
	    		if(input==null){
	    	            log.info("Sorry, unable to find " + filename);
	    		    
	    		}

	    	
	    		prop.load(input);
	    
	    	
	    	
	 
	    	} catch (IOException ex) {
	    		ex.printStackTrace();
	        } finally{
	        	if(input!=null){
	        		try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
	        	}
	        }
			
			
		        for (int j = 0; j < stringArray.length; j++) {
				
					stringArray[j]=stringArray[j].trim();
					log.info(stringArray[j]);
				}
		    
		    	String DBUser=prop.getProperty("DBUser");
		    	log.info(DBUser);
		    	String CabinetName=prop.getProperty("ImportcabinetName");
		    	String DBIP=prop.getProperty("DBIP");
		    	String DBPassword=prop.getProperty("DBPassword");
		    	String Path=prop.getProperty("Path");
		    	String ServiceName=prop.getProperty("ServiceName");
		    	String DBport=prop.getProperty("DBport");
		    	String OMSPath=prop.getProperty("OMNIOMSPath");
	
		    	log.info(FolderName);
		
		    	try{
		    	
		    		con=ConnectionManager.getConnection(DBUser, DBPassword, DBIP, DBport, ServiceName);}
		    catch(Exception e){
		    	
		    		
		    		
		    	}
			for (int k = 0; k < stringArray.length; k++) {
				
				log.info("Entering the loop for k = " + k);
				Statement stmt = con.createStatement();
				int Category1 = 0;
				int Comm1 = 0;
				int version1 = 0 ;
				String version=null;
				String Comm=null;
				String Category=null;
				String version2 = null;
				String Checkout = null;
				String query="select * from ReportMast where ProductName='" + stringArray[k] + "'";
				ResultSet rs = stmt.executeQuery("select * from ReportMast where ProductName='" + stringArray[k] + "'");
				while (rs.next()) {
					log.info(rs.getString(1) + "  " + rs.getString(2) + "  " + rs.getString(3));
					Category1 = rs.getInt(2);
					Comm1 = rs.getInt(3);
					version1 = rs.getInt(1);
					version2 = rs.getString(13);
					Checkout = rs.getString(7);
					 version=String.format("%08d", version1);
					 Comm=String.format("%04d", Comm1);
					Category=String.format("%04d", Category1);
				}
		
				
				File files1 = new File(Path+"/Backup/" +FolderName+"/"+ stringArray[k] + "");
				if (!files1.exists()) {
					if (files1.mkdirs()) {
						log.info("Multiple directories are created!");
					} else {
						log.info("Failed to create multiple directories!");
					}
				}
	
				
				
				try {
					String xml_path = OMSPath+"NEWGEN OmniOMS/OmniOMS Designer/Layout/"+CabinetName+"/" + Category + "/" + Comm
							+ "/Designs/1/" + version + "_v" + version2 + ".xml";
					log.info(" Xml replaced is"+xml_path);
					java.nio.file.Path destination_xml = Paths.get(xml_path);
					java.nio.file.Path source_xml  = Paths
							.get(ImportPath1+"/"+stringArray[k] + "/xml.xml");
					java.nio.file.Path Backup_xml=Paths
							.get(Path+"/Backup/"+FolderName+"/" + stringArray[k] + "/xml.xml");
					log.info("sourceXML "+ source_xml+" destinationXML "+destination_xml+"Backup xml is" + Backup_xml);
					Files.copy(destination_xml, Backup_xml, StandardCopyOption.REPLACE_EXISTING);
					Files.copy(source_xml, destination_xml, StandardCopyOption.REPLACE_EXISTING);
				} catch (Exception ex) {
					log.info("Checked out on other Device");
				
					
					continue;
				}
				
				try {
					String tiff_path = OMSPath+"NEWGEN OmniOMS/OmniOMS Designer/Images/"+CabinetName+"/" + Category + "/" + Comm
							+ "/Designs/1/" + version + "_v" + version2 + ".tiff";
					log.info(tiff_path);
					java.nio.file.Path  Destination_tiff= Paths.get(tiff_path);
					java.nio.file.Path source_Tiff = Paths
							.get(ImportPath1+"/"+ stringArray[k] + "/tiff.tiff");
				 
					java.nio.file.Path Backup_tiff=Paths
							.get(Path+"/Backup/"+FolderName+"/"+ stringArray[k] + "/tiff.tiff");
					if (Files.exists(Backup_tiff))
					{
					log.info("sourceTiff "+ source_Tiff+" destinationTiff "+Destination_tiff+"Backup Tiff is" + Backup_tiff);
					Files.copy(Destination_tiff, Backup_tiff, StandardCopyOption.REPLACE_EXISTING);
					Files.copy(source_Tiff, Destination_tiff, StandardCopyOption.REPLACE_EXISTING);
					}
					else
					{
						Files.copy(source_Tiff, Destination_tiff, StandardCopyOption.REPLACE_EXISTING);
					}
				} catch (Exception ex) {
					log.info("No Tiff Exists");

				}
				String Relation_path = OMSPath+"NEWGEN OmniOMS/OmniOMS Designer/Relation/"+CabinetName+"/" + Category + "/"
						+ Comm + "/Relation.xml";
				log.info(Relation_path);
				java.nio.file.Path Destination_Relation = Paths.get(Relation_path);
				java.nio.file.Path source_Relation  = Paths
						.get(ImportPath1+"/"+ stringArray[k] + "/Relation.xml");
				java.nio.file.Path Backup_Relation=Paths
						.get(Path+"/Backup/"+FolderName+"/"+ stringArray[k] + "/Relation.xml");
				log.info("sourceRelation "+ source_Relation+" destinationRelation "+Destination_Relation+"Backup Relation is" + Backup_Relation);
				Files.copy(Destination_Relation, Backup_Relation, StandardCopyOption.REPLACE_EXISTING);
				Files.copy(source_Relation, Destination_Relation, StandardCopyOption.REPLACE_EXISTING);
	}
			ZipUtils.zipFolder(Path+"/Backup/"+FolderName, Path+"/Backup/"+FolderName+".zip");
			System.gc();
			dl.delete(ImportPath);
			dl.delete(Path+"/Backup/"+FolderName);
			File f3=new File(ImportPath+".zip");
			f3.renameTo(new File(ImportPath+".mdb"));
			
			evo.setOutput("Success");
			
		} catch (Exception e) {
			e.printStackTrace();
			log.info(e.toString());
		}
		
		Response response = null;
		response = Response.status(200).entity(evo).build();
		return response;
		
	}
	
	
}
