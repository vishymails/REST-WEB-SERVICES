package com.newgen.rest.service;

import java.io.File;
import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

 public class Logs {
	 static Logger logger = Logger.getLogger("MyLog");  
	

		
		
	public static Logger main() throws IOException {  

	   
	    

	    try {  

	        // This block configure the logger with handler and formatter  
	      // File fl=new File("C:/Users/pulkit.bansal/Desktop/MyLogFile.log");
	 
	  
	   	 
	    	FileHandler fh=new FileHandler("C:/Users/pulkit.bansal/Desktop/MyLogFile.log",true);
	    	logger.addHandler(fh);
	        SimpleFormatter formatter = new SimpleFormatter();  
	        fh.setFormatter(formatter);  

	        // the following statement is used to log any messages  
	    //    logger.info("My first log");  

	     
	 logger.info("hello");
	 
	 
	   
	    }catch (SecurityException e) {  
	        e.printStackTrace();  
	    }
	//	return logger;  
		return logger;

	//    logger.info("Hi How r u?");
		//return logger;  

	}
}
 
