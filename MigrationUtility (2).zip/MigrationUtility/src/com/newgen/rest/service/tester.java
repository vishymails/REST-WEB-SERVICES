package com.newgen.rest.service;

import java.io.IOException;

public class tester {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		TemplateImportVO tv=new TemplateImportVO();
		//String[] stringArray={"CHQSTOPPMNT"};
		tv.setFolderPath("C:/Users/pulkit.bansal/Desktop/Export/1525350336430.mdb");
		TestRestServiceClass ts=new TestRestServiceClass();
		System.out.println(System.getProperty("user.dir"));
		ts.ImportVerify(tv);
	}

}
