package com.newgen.rest.service;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.newgen.rest.service.ConnectionManager;
import com.newgen.rest.service.property;

public class CheckExportScript {
	static Logger log = Logger.getLogger(CheckExportScript.class.getName());
	public static String getScript() throws ClassNotFoundException, SQLException{
		// TODO Auto-generated method stub
	//	MigrationOutputVO mvo = new MigrationOutputVO();
		Properties prop = new Properties();
		InputStream input = null;
		String Key = null;
		//ArrayList<String> faultlist = new ArrayList<String>();
		try {

			String filename = "abc.properties";
			input = property.class.getClassLoader().getResourceAsStream(filename);
			if (input == null) {
				log.info("Sorry, unable to find " + filename);
		
			}

			prop.load(input);

		} catch (IOException ex) {
			ex.printStackTrace();
			
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					//e.printStackTrace();
					log.info("Sorry Data not found");
				}
			}
		}
		String DBIP = prop.getProperty("DBIP");
		String DBPassword = prop.getProperty("DBPassword");
		String ServiceName=prop.getProperty("ServiceName");
		String DBport=prop.getProperty("DBport");
		String Cabinet=prop.getProperty("ImportcabinetName");
		Cabinet=Cabinet.toUpperCase();
		//String OMSPath=prop.getProperty("OMNIOMSPath");
		String OMSPath= prop.getProperty("OMNIOMSPath");
		String CabinetName = prop.getProperty("ExportCabinetName");
		String DBUser = prop.getProperty("DBUser");
		//String Category= null;
		//String Comm=null;
		int count = -1;
		Connection con=null;
		con=ConnectionManager.getConnection(DBUser, DBPassword,DBIP,DBport, ServiceName);
		Statement stmt = con.createStatement();
		
		int Category1 = 0;
		int Comm1 = 0;
		int version1 = 0 ;
		String version=null;
		
		String version2 = null;
		String Checkout = null;
		//Statement stmt = con.createStatement();
		TemplateInputVO vo =new TemplateInputVO();
		String[] stringArray = vo.getProductNameArray();
		
		//String[] stringArray = {"CHQSTOPPMNT","SYNDLOANSTMT","SAMBATEST"};
		String scriptData=null;
		for(int k1=0;k1<stringArray.length;k1++)
		{
			
			String query="select * from ReportMast where ProductName='" + stringArray[k1] + "'";
			ResultSet rs = stmt.executeQuery("select * from ReportMast where ProductName='" + stringArray[k1] + "'");
		
			String Comm=null;
			String Category=null;
			while (rs.next()) {

				Category1 = rs.getInt(2);
				Comm1 = rs.getInt(3);
				version1 = rs.getInt(1);
				version2 = rs.getString(13);
				Checkout = rs.getString(7);
				 version=String.format("%08d", version1);
				 Comm=String.format("%04d", Comm1);
				Category=String.format("%04d", Category1);
			}
			
			File Relationfile1=new File( OMSPath+"NEWGEN OmniOMS/OmniOMS Designer/Relation/"+CabinetName+"/" + Category + "/"
					+ Comm + "/Relation.xml");
			
			//System.out.println(OMSPath+"NEWGEN OmniOMS/OmniOMS Designer/Relation/"+CabinetName+"/" + Category + "/"+ Comm + "/Relation.xml");
			ArrayList<String> TablesName=ExportScriptTableName.RelationPrase(Relationfile1);
			
			/*ArrayList<String> TablesName= new ArrayList<>();
			TablesName.add("V_USR_0_STANDINGAPPSWIFT");//Adding object in arraylist  
			TablesName.add("USERMAST");  
			TablesName.add("USERGROUPRELATION");  
			//TablesName.add("Ajay");
	*/		
			
			if(TablesName.isEmpty())
			{
				log.info("Table/View does not exist in "+DBUser+" "+CabinetName+"");
			}
			else
			{
				
				ArrayList<String> tables = new ArrayList<>();
				ArrayList<String> views = new ArrayList<>();
			
				 for(String obj: TablesName){
					 if(obj.contains("V_")){
						 views.add(obj);
						
					 }
					
					 else{
						 tables.add(obj);
						
					 }
				 }
				 System.out.println("Views in current report are: "+views);
				 log.info("Views in current report are: "+views);
				 System.out.println("Tables in current report are: "+tables);
				 log.info("Tables in current report are: "+tables);
				
				 for(String t: tables){
					 String qry="select dbms_metadata.get_ddl( 'TABLE', '"+t+"', '"+CabinetName+"' ) from dual"  ;
						ResultSet rs1 = stmt.executeQuery(qry);
						
						while (rs1.next()) {
							scriptData+= rs1.getString(1);
							if(!scriptData.isEmpty()) scriptData += "\n\n";
							System.out.println(scriptData);
							log.info("Complete Script Data is : "+scriptData);
						}
				 }
				 for(String v: views){
					 String qry="select dbms_metadata.get_ddl( 'VIEW', '"+v+"', '"+CabinetName+"' ) from dual"  ;
						ResultSet rs1 = stmt.executeQuery(qry);
						
						while (rs1.next()) {
							scriptData+= rs1.getString(1);
							if(!scriptData.isEmpty()) scriptData += "\n\n";
							System.out.println(scriptData);
							log.info("Complete Script Data is : "+scriptData);
						}
				 }
			
		        
				//return scriptData;
		    }
			
		}
	
		
		/*File Relationfile1=new File( OMSPath+"NEWGEN OmniOMS/OmniOMS Designer/Relation/"+CabinetName+"/" + Category + "/"
				+ Comm + "/Relation.xml");
		
		//System.out.println(OMSPath+"NEWGEN OmniOMS/OmniOMS Designer/Relation/"+CabinetName+"/" + Category + "/"+ Comm + "/Relation.xml");
		ArrayList<String> TablesName=ExportScriptTableName.RelationPrase(Relationfile1);
		
		ArrayList<String> TablesName= new ArrayList<>();
		TablesName.add("V_USR_0_STANDINGAPPSWIFT");//Adding object in arraylist  
		TablesName.add("USERMAST");  
		TablesName.add("USERGROUPRELATION");  
		//TablesName.add("Ajay");
		String scriptData=null;
		
		if(TablesName.isEmpty())
		{
			log.info("Table/View does not exist in "+DBUser+" "+CabinetName+"");
		}
		else
		{
			
			ArrayList<String> tables = new ArrayList<>();
			ArrayList<String> views = new ArrayList<>();
		
			 for(String obj: TablesName){
				 if(obj.contains("V_")){
					 views.add(obj);
					
				 }
				
				 else{
					 tables.add(obj);
					
				 }
			 }
			 System.out.println("Views in current report are: "+views);
			 log.info("Views in current report are: "+views);
			 System.out.println("Tables in current report are: "+tables);
			 log.info("Tables in current report are: "+tables);
			
			 for(String t: tables){
				 String qry="select dbms_metadata.get_ddl( 'TABLE', '"+t+"', '"+CabinetName+"' ) from dual"  ;
					ResultSet rs1 = stmt.executeQuery(qry);
					
					while (rs1.next()) {
						scriptData+= rs1.getString(1);
						if(!scriptData.isEmpty()) scriptData += "\n\n";
						System.out.println(scriptData);
						log.info("Complete Script Data is : "+scriptData);
					}
			 }
			 for(String v: views){
				 String qry="select dbms_metadata.get_ddl( 'VIEW', '"+v+"', '"+CabinetName+"' ) from dual"  ;
					ResultSet rs1 = stmt.executeQuery(qry);
					
					while (rs1.next()) {
						scriptData+= rs1.getString(1);
						if(!scriptData.isEmpty()) scriptData += "\n\n";
						System.out.println(scriptData);
						log.info("Complete Script Data is : "+scriptData);
					}
			 }
		
	        
			//return scriptData;
	    }*/
		return scriptData;	
	}
	
	public static void main(String[] args) throws ClassNotFoundException, SQLException, FileNotFoundException {
		OutputStream os = null;
	//Writing Error to Error File
		System.err.println("This goes to the console");
		PrintStream console = System.err;
		PrintStream ps = new PrintStream(new FileOutputStream(new File("C:/Users/vishal.verma/Desktop/Samba Newgen Migration Tool/Export/error.txt")));
		System.setErr(ps);
		System.err.println("This goes to err.txt");
		
        try {
            os = new FileOutputStream(new File("C:/Users/vishal.verma/Desktop/Samba Newgen Migration Tool/Export/os.sql"));
            os.write(getScript().getBytes(), 0, getScript().length());
        } catch (IOException e) {
            e.printStackTrace();
        }
       /* System.setErr(console);
		System.err.println("This also goes to the console");*/
	}
		}



