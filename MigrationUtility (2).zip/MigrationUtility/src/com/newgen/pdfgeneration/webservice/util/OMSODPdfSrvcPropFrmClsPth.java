/***************************************************************************
 *	NEWGEN SOFTWARE TECHNOLOGIES LIMITED

 *	Group					: AP2
 *	Product / Project       : Output Management System
 *	Module					: ODPdfGenerationRestWS
 *	File Name				: GenerateDocumentClient
 *	Author					: Akashdeep Tyagi
 *	Date written(DD/MM/YYYY): 10/08/2017
 *	Purpose					: Used for making generateDocument call to product

 *****************************************************************************
 *	Change History:
 *****************************************************************************
 *	 SNo	Date		Change By			Change Description (Bug No. If Any) 
 *	  1		28/12/2017	Akashdeep Tyagi		Create Property file for configuration outside the project (ODPdfGenerationRestWS) file (1022447)	
 *****************************************************************************/
package com.newgen.pdfgeneration.webservice.util;

import java.io.FileInputStream;
import java.util.Properties;

public class OMSODPdfSrvcPropFrmClsPth {
	public static String getProperty(String keyname) {
		String elementname = p.getProperty(keyname);
		return elementname;
	}

	private static final String propsFile = "abc.properties";
	private static boolean readProperties;
	private static Properties p;

	static {
		if (!readProperties) {
			readProperties();
		}
	}

	public static void readProperties() {
		try {

			p = new Properties();
			p.load(OMSODPdfSrvcPropFrmClsPth.class.getClassLoader().getResourceAsStream(propsFile));

			readProperties = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void reloadProperties() {
		readProperties();
	}
}
