package GeoLocate;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;

import javax.ws.rs.Consumes;

import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

@Path("/geoExecution")
public class ExecuteResult {
	
	@POST
	@Produces(value = { MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes(value = { MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	
	@Path("/calculateDistance")
	public Response distancecalculation(LatLon ll) throws IOException{
		
		//CalDistResult cdr = new CalDistResult();
		double dist = Distance.getDistanceFromLatLonInKm(ll.Lat1, ll.Lon1, ll.Lat2, ll.Lon2);
		double val= Math.round(dist*100.0)/100.0;
		System.out.println("kiloMeter (Math.round) : " + val);
		
		PositionVO pv = new PositionVO();
		pv.setDistanceKM(val);
		/*pv.setResult(val);
		pv.setS("distanceKM:");
		cdr.Distancefatched.add(pv);*/
		
		Response response = null;
		response = Response.status(200).entity(pv).build();
		return response;
	}
	

	@POST
	@Produces(value = { MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes(value = { MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	
	@Path("/nearByLatLong")
	public Response nearBy(GeoPoints gp) throws IOException{
		
		ArrayList<ReferencePoint> refp= gp.getReferencePoint();
		for(ReferencePoint rp:refp){
			ReferencePoint rp1 = new ReferencePoint();
			rp1.setLatitude(rp.Latitude);
			rp1.setLongitude(rp.Longitude);
			System.out.println(rp.Latitude+" "+rp.Longitude);
		}
		double radiusDist = gp.getDistanceKM();
		System.out.println(radiusDist);
		CalDistResult cdr = new CalDistResult();
		cdr.setResult(new ArrayList<PositionVOGeoPoint>());
		ArrayList<LatLon2> ll = gp.getArray();
		System.out.println(new Gson().toJson(ll));
		
		
		
		/* ArrayList<PositionVO> ps = new ArrayList<PositionVO>();*/
		  for(LatLon2 l:ll){

			  /*LatLon2 newll = new LatLon2();
				newll.setLat2(l.Lat2);
				newll.setLon2(l.Lon2);*/
			  System.out.println("distance :::: "+Distance.getDistanceFromRef(gp.getReferencePoint().get(0),l.Lat2, l.Lon2));
			  if(Distance.getDistanceFromRef(gp.getReferencePoint().get(0),l.Lat2, l.Lon2)<=radiusDist){
				 
				  System.out.println("inner distance :::: "+Distance.getDistanceFromRef(gp.getReferencePoint().get(0),l.Lat2, l.Lon2));
				  PositionVOGeoPoint pvgp = new PositionVOGeoPoint();
				  pvgp.setLatitude(l.getLat2());
				  pvgp.setLongitude(l.getLon2());
				  cdr.getResult().add(pvgp);
				 
				 // System.out.println(getDistanceFromLatLongInKm(l.Lat, l.Lon));
				// System.out.println( p.getLon()+" "+ p.getLat());
				 
			  }
			  
		  }
				
		Response response = null;
		response = Response.status(200).entity(cdr).build();
		return response;
	}
	/*public static void main(String[] args) throws IOException {
		ExecuteResult er = new ExecuteResult();
		//System.out.println(er.distancecalculation(new LatLon(28.458581, 77.071464, 28.463296, 77.094853)));
	}*/
}
