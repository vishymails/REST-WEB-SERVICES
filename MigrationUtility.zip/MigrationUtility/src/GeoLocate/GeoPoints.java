package GeoLocate;

import java.util.ArrayList;

public class GeoPoints {
	
	ArrayList<LatLon2> array = new ArrayList<LatLon2>();
	ArrayList<ReferencePoint> referencePoint = new ArrayList<ReferencePoint>();
	public double distanceKM;
	
	
	public ArrayList<LatLon2> getArray() {
		return array;
	}

	public void setArray(ArrayList<LatLon2> array) {
		this.array = array;
	}

	public ArrayList<ReferencePoint> getReferencePoint() {
		return referencePoint;
	}

	public void setReferencePoint(ArrayList<ReferencePoint> referencePoint) {
		this.referencePoint = referencePoint;
	}

	public double getDistanceKM() {
		return distanceKM;
	}

	public void setDistanceKM(double distanceKM) {
		this.distanceKM = distanceKM;
	}

	
	
	
}
