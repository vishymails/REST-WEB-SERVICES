package com.newgen.rest.service;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Properties;

import org.apache.log4j.Logger;

public class TestTable {
	static Logger log = Logger.getLogger(TestTable.class.getName());
	public static ArrayList<String> Tabletester(ArrayList<String> tablenames) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
	//	MigrationOutputVO mvo = new MigrationOutputVO();
		Properties prop = new Properties();
		InputStream input = null;
		String Key = null;
		ArrayList<String> faultlist = new ArrayList<String>();
		try {

			String filename = "abc.properties";
			input = property.class.getClassLoader().getResourceAsStream(filename);
			if (input == null) {
				//log.info("Sorry, unable to find " + filename);
				log.info("Sorry, unable to find " + filename);

			}

			prop.load(input);

		} catch (IOException ex) {
			ex.printStackTrace();
			log.info(ex.toString());
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					//e.printStackTrace();
					log.info(e.toString());
				}
			}
		}
		String DBIP = prop.getProperty("DBIP");
		String DBPassword = prop.getProperty("DBPassword");
		String ServiceName=prop.getProperty("ServiceName");
		String DBport=prop.getProperty("DBport");
		String Cabinet=prop.getProperty("ImportcabinetName");
		Cabinet=Cabinet.toUpperCase();
		ArrayList<String> TableName=tablenames;
		String DBUser = prop.getProperty("DBUser");
		int count = -1;
		Connection con=null;
		con=ConnectionManager.getConnection(DBUser, DBPassword,DBIP,DBport, ServiceName);
		Statement stmt = con.createStatement();
		for(int k=0;k<TableName.size();k++)
		{
		String sql="select count(*) from all_objects where object_type in ('TABLE','VIEW') and object_name = '"+TableName.get(k)+"'and owner='"+Cabinet+"'";
		ResultSet rs=	stmt.executeQuery(sql);
		while (rs.next())
				{
					 count=rs.getInt(1);
				}
		if(count>=0)
		{
			if(count==0)
				{
					System.out.println(k+"Table Does Not Exist");
					log.info("Table Does Not Exist "+ TableName.get(k));
					faultlist.add(TableName.get(k));
				}
			if(count>0)
				{
					System.out.println("Table Exist "+ TableName.get(k));
					log.info("Table Exist "+ TableName.get(k));
				}
		}
		else
		{
			System.out.println(k+"Not Able to Execute Query");
		}
		}
		System.out.println("Number of tables Faulty are "+faultlist);
		return faultlist;
		}

}
