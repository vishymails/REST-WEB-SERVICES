package com.newgen.rest.service;

import java.io.IOException;
import java.util.logging.FileHandler;

public class FileCreator {
public static void CreateFile() throws SecurityException, IOException{
	FileHandler fh = new FileHandler("C:/Users/pulkit.bansal/Desktop/Logs/MyLogFile.log",true);
	}
}

