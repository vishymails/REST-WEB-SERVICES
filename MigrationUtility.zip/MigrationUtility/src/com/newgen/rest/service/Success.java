package com.newgen.rest.service;

public class Success {
	String Productname;

	public String getProductname() {
		return Productname;
	}

	public void setProductname(String productname) {
		Productname = productname;
	}

}
