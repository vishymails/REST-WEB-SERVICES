package com.newgen.inviewfo.constants;


public interface IAppConfigConstants {
	/*
	 * Declaring constants for Application level, general settings.
	 */
	public static final String CONTENTTYPE_JSON = "application/json";
	public static final String ACTION = "action";
	public static final String SERVER_DOMAIN_DIR = "user.dir";
	public static final String FILE_SEPARATOR = "file.separator";
	public static final String LOGGING_SETUP_PROPFILE_NAME = "loggingSetup.properties";
	
	public static final String LOGLEVEL_INFO = "INFO";
	public static final String LOGLEVEL_DEBUG = "DEBUG";
	public static final String LOGLEVEL_WARN = "WARN";
	public static final String LOGLEVEL_ERROR = "ERROR";
	public static final String LOGLEVEL_FATAL = "FATAL";
	public static final String LOGLEVEL_ALL = "ALL";
	public static final String LOGLEVEL_OFF = "OFF";
	
}
