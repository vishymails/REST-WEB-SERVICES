package Test;

import java.io.*;
import org.xhtmlrenderer.pdf.ITextRenderer;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.html.simpleparser.HTMLWorker;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.tool.xml.XMLWorkerHelper;




public class HtmlToPdf {
	
	public static void main(String args[]) throws DocumentException, IOException{
		/*String File_To_Convert = "index.html";
		String url= new File(File_To_Convert).toURI().toURL().toString();
		System.out.println(""+url);
		String HTML_to_Pdf = "ConvertedFile.pdf";
		FileOutputStream os= new FileOutputStream(HTML_to_Pdf);
		ITextRenderer renderer= new ITextRenderer();
		renderer.setDocument(url);
		renderer.layout();
		renderer.createPDF(os);
		os.close();*/
		
		//JTidy Converter for HTML to XHTML
		
		
		
		//JTidy Converter for HTML to XHTML		
		
		try {
			
			StringBuilder contentBuilder = new StringBuilder();
			try {
			    BufferedReader in = new BufferedReader(new FileReader("D:\\t2.html"));
			    String str;
			    while ((str = in.readLine()) != null) {
			        contentBuilder.append(str);
			    }
			    in.close();
			} catch (IOException e) {
			}
			String content = contentBuilder.toString();
			
			OutputStream os= new FileOutputStream(new File("D:\\fun.pdf"));
			
			Document doc= new Document();
			PdfWriter pf=PdfWriter.getInstance(doc, os);
			doc.open();
			doc.addAuthor("Real Gagnon");
			doc.addCreator("Real's HowTo");
			doc.addSubject("Thanks for your support");
			doc.addCreationDate();
			doc.addTitle("Please read this");
			
			PdfPTable table = new PdfPTable(1);
			PdfPCell cell; 
			cell = new PdfPCell(new Phrase("Cell with colspan 3"));
	        cell.setColspan(3);
	        table.addCell(cell);
	        // now we add a cell with rowspan 2
	        cell = new PdfPCell(new Phrase("Cell with rowspan 2"));
	        cell.setRowspan(2);
	        table.addCell(cell);
	        // we add the four remaining cells with addCell()
	        table.addCell("row 1; cell 1");
	        table.addCell("row 1; cell 2");
	        table.addCell("row 2; cell 1");
	        table.addCell("row 2; cell 2");
			doc.add(table);
			
			/*InputStream is= new ByteArrayInputStream(a.getBytes());
			XMLWorkerHelper.getInstance().parseXHtml(pf, doc, is);*/
			
			
			
			HTMLWorker hw=new HTMLWorker(doc);
			hw.parse(new StringReader(content));
			content="";
			doc.close();
			os.close();
		} catch (Exception e) {
				e.printStackTrace();
		}
	}
}
